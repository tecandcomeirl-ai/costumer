from odoo import api, fields, models


class AccountMove(models.Model):
    _inherit = 'account.move'

    series_id = fields.Many2one(
        'document.series', string='Serie', copy=False, tracking=True,
        domain="[('model_name', '=', 'account.move'),"
               " ('company_id', '=', company_id),"
               " '|', ('journal_id', '=', journal_id), ('journal_id', '=', False)]",
    )

    @api.onchange('journal_id')
    def _onchange_journal_series(self):
        if self.journal_id and self.is_sale_document(include_receipts=True):
            self.series_id = self.env['document.series'].search([
                ('model_name', '=', 'account.move'),
                ('company_id', '=', self.company_id.id),
                ('journal_id', '=', self.journal_id.id),
            ], limit=1)

    def _post(self, soft=True):
        # Asigna el número de la serie antes de publicar
        for move in self.filtered(
                lambda m: m.series_id and m.name in (False, '/', 'New')):
            move.name = move.series_id.get_next_number()
        return super()._post(soft=soft)
